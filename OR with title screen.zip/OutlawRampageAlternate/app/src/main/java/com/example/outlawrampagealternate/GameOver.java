package com.example.outlawrampagealternate;

import android.graphics.Point;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.widget.ImageView;

public class GameOver extends AppCompatActivity {

    private ImageView background2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        background2 = findViewById(R.id.background2);
        background2.setImageResource(R.drawable.cowboy_graveyard);
    }
}
