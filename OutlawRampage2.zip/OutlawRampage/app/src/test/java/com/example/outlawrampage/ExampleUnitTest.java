package com.example.outlawrampage;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {

//    @Test
//    public void getRightTest () {
//        MainActivity main = new MainActivity();
//
//        assertEquals(main.right, main.getRight());
//    }
//
//    @Test
//    public void getLeftTest () {
//        MainActivity main = new MainActivity();
//
//        assertEquals(main.left, main.getLeft());
//    }
//
//    @Test
//    public void getJumpTest () {
//        MainActivity main = new MainActivity();
//
//        assertEquals(main.jump, main.getJump());
//    }
//
//    @Test
//    public void getRunnerTest () {
//        MainActivity main = new MainActivity();
//
//        assertEquals(main.runner, main.getRunner());
//    }

}