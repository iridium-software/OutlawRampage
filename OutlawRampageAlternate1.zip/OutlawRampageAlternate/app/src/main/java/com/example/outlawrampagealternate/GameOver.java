package com.example.outlawrampagealternate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;

public class GameOver extends AppCompatActivity implements View.OnTouchListener{

    private ImageView background2;
    private ImageButton restartButton;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        background2 = findViewById(R.id.background2);
        background2.setImageResource(R.drawable.cowboy_graveyard);

        restartButton = findViewById(R.id.RestartButton);
        restartButton.setOnTouchListener(this);
    }

    public boolean onTouch(View v, MotionEvent event) {
        switch (v.getId()) {
            case R.id.RestartButton:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startGame();
                        finish();
                }
                return true;


            default:
                return false;
        }
    }

    public void startGame() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
