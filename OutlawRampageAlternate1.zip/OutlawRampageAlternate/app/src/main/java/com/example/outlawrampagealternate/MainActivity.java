package com.example.outlawrampagealternate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    private ImageButton right;
    private ImageButton left;
    private ImageButton jump;
    private ImageButton shoot;
    private ImageButton next;
    private ImageView Jebediah;
    private ImageView bullet;
    private ImageView Indian;
    private ImageView Indian2;
    private ImageView ground;
    private ImageView platform1;
    private ImageView platform2;
    private boolean indianDead = false;
    private boolean indianDead2 = false;
    private ImageView arrow;
    private ImageView arrow2;
    private ImageView gold;
    private float currentLevel;
    private int jumpCount;
    private AnimationDrawable cowboyWaltz;
    private AnimationDrawable cowboyJump;
    private AnimationDrawable cowboyShoot;
    private Handler handler = new Handler();
    private Timer timer;
    private Values values = new Values();

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Jebediah = findViewById(R.id.Jebediah);
        Jebediah.setImageResource(R.drawable.cowboy4_walkwithoutgun_0);

        bullet = findViewById(R.id.bullet);
        jumpCount = 0;
        currentLevel = values.getCurrentLevel();

        right = findViewById(R.id.right);
        right.setOnTouchListener(this);


        left = findViewById(R.id.left);
        left.setOnTouchListener(this);


        jump = findViewById(R.id.jump);
        jump.setOnTouchListener(this);

        shoot = findViewById(R.id.shoot);
        shoot.setOnTouchListener(this);

        next = findViewById(R.id.next);
        next.setOnTouchListener(this);

        Indian = findViewById(R.id.Indian);
        Indian.setImageResource(R.drawable.indian);
        Indian2 = findViewById(R.id.Indian2);
        Indian2.setImageResource(R.drawable.indian);

        arrow = findViewById(R.id.arrow);
        arrow2 = findViewById(R.id.arrow2);

        platform1 = findViewById(R.id.platform1);
        platform2 = findViewById(R.id.platform2);

        // image from Bonsaiheldin | http://bonsaiheld.org
        gold = findViewById(R.id.gold);

        ground = findViewById(R.id.ground);

        indianAttack();
        indianAttack2();
        setVis();
        killJeb();
        fall();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        final int width = size.x;

        switch (v.getId()) {
            case R.id.right:
                Jebediah.setImageResource(R.drawable.cowboywaltz);
                //citation: https://www.youtube.com/watch?v=06rVQ1kUXc4
                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        //citation: https://www.youtube.com/watch?v=UxbJKNjQWD8
                        timer = new Timer(); //need to start a new timer every time you press the button
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Jebediah.setX(Jebediah.getX() + values.getWalkingSpeedRight());

                                        if (Jebediah.getDrawable() instanceof AnimationDrawable) {
                                            cowboyWaltz = (AnimationDrawable) Jebediah.getDrawable();
                                        }
                                        cowboyWaltz.start();
                                    }
                                });
                            }
                        }, 1, 50);
                        return true;

                    case MotionEvent.ACTION_UP:
                        cowboyWaltz.stop();
                        Jebediah.setImageResource(R.drawable.cowboy4_walkwithoutgun_0);
                        timer.cancel(); //end the timer when you release the button
                        return true;
                }

                return false;

            case R.id.left:
                Jebediah.setImageResource(R.drawable.cowboywaltz);
                //citation: https://www.youtube.com/watch?v=06rVQ1kUXc4
                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:

                        //citation: https://www.youtube.com/watch?v=UxbJKNjQWD8
                        timer = new Timer(); //need to start a new timer every time you press the button
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Jebediah.setX(Jebediah.getX() + values.getWalkingSpeedLeft());
                                        if (Jebediah.getDrawable() instanceof AnimationDrawable) {
                                            cowboyWaltz = (AnimationDrawable) Jebediah.getDrawable();
                                        }
                                        cowboyWaltz.start();
                                    }
                                });
                            }
                        }, 1, 50);
                        return true;

                    case MotionEvent.ACTION_UP:
                        cowboyWaltz.stop();
                        Jebediah.setImageResource(R.drawable.cowboy4_walkwithoutgun_0);
                        timer.cancel(); //end the timer when you release the button
                        return true;
                }

                return false;

            case R.id.jump:

                //citation: https://www.youtube.com/watch?v=06rVQ1kUXc4
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Jebediah.setImageResource(R.drawable.cowboyjump);
                        if (Jebediah.getY() == currentLevel) {
                            jumpCount = 0;
                        }
                        if (jumpCount == 0) {
                            final long startTime = System.currentTimeMillis();
                            //citation: https://www.youtube.com/watch?v=UxbJKNjQWD8
                            timer = new Timer(); //need to start a new timer every time you press the button
                            timer.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                    for (int i = 0; i < 10; i++) {
                                        //citation: https://www.youtube.com/watch?v=PGMrMZLNhUk
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                Jebediah.setY(Jebediah.getY() + values.getJumpUpSpeed());
                                                Jebediah.setX(Jebediah.getX() + values.getJumpOverSpeed());
                                                cowboyJump = (AnimationDrawable) Jebediah.getDrawable();
                                                cowboyJump.start();

                                                if (values.checkPlatformLevel(Jebediah.getX(),
                                                        Jebediah.getY() + Jebediah.getHeight())) {
                                                    currentLevel = values.getCurrentLevel();
                                                    timer.cancel();
                                                }

                                            }
                                        }, 500);
                                    }
                                    if (System.currentTimeMillis() >= startTime + 500) {
                                        timer.cancel();
                                    }
                                    for (int i = 0; i < 10; i++) {
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                if (Jebediah.getY() < currentLevel) {
                                                    Jebediah.setY(Jebediah.getY() + values.getJumpDownSpeed());
                                                }
                                                cowboyJump.stop();
                                                Jebediah.setImageResource(R.drawable.cowboystance);
                                                jumpCount++;
                                            }
                                        }, 1000);
                                    }
                                }
                            }, 1, 50);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        Jebediah.setY(currentLevel);
                        if (timer != null) {
                            timer.cancel(); //end the timer when you release the button
                        }
                        return true;
                }

                return false;

            case R.id.shoot:


                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        Jebediah.setImageResource(R.drawable.cowboyshoot);
                        bullet.setImageResource(R.drawable.bullet);// need a bullet sprite
                        final float JebX = Jebediah.getX();
                        final float JebY = Jebediah.getY();
                        bullet.setX(JebX + 150);
                        bullet.setY(JebY + 75);
                        bullet.setVisibility(View.VISIBLE);

                        //citation: https://www.youtube.com/watch?v=UxbJKNjQWD8
                        timer = new Timer(); //need to start a new timer every time you press the button
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        bullet.setX(bullet.getX() + values.getBulletSpeed());
                                        if (Jebediah.getDrawable() instanceof AnimationDrawable) {
                                            cowboyShoot = (AnimationDrawable) Jebediah.getDrawable();
                                        }
                                        cowboyShoot.start();

                                        killIndian();
                                        killIndian2();

                                        if ((int) bullet.getX() >= width) {
                                            bullet.setVisibility(View.INVISIBLE);
                                        }
                                    }
                                }, 250);
                            }
                        }, 1, 50);
                }
                return false;

            case R.id.next:
                switch (event.getAction()) {

                    case MotionEvent.ACTION_DOWN:
                        if (gotToGold()) {
                            winLevel();
                            finish();
                        }
                        return true;
                }
            default:
                return false;
        }
    }

    public void killIndian() {
        if (bullet.getX() >= Indian.getX() && bullet.getX() <= Indian.getX() + Indian.getWidth() &&
                bullet.getY() >= Indian.getY() && bullet.getY() <= Indian.getY() + Indian.getHeight()) {
            Indian.setVisibility(View.INVISIBLE);
            arrow.setVisibility(View.INVISIBLE);
            indianDead = true;
        }
    }

    public void killIndian2() {
        if (bullet.getX() >= Indian2.getX() && bullet.getX() <= Indian2.getX() + Indian2.getWidth() &&
                bullet.getY() >= Indian2.getY() && bullet.getY() <= Indian2.getY() + Indian2.getHeight()) {
            Indian2.setVisibility(View.INVISIBLE);
            arrow2.setVisibility(View.INVISIBLE);
            indianDead2 = true;
        }
    }

    public void killJeb() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (arrow.getX() <= Jebediah.getX() + 100 && arrow.getX() >= Jebediah.getX() &&
                                arrow.getY() >= Jebediah.getY() && arrow.getY() <= Jebediah.getY() + 125 &&
                                !indianDead) {
                            gameOver();
                            timer.cancel();
                            indianDead = true;
                            indianDead2 = true;
                        }

                        if (arrow2.getX() <= Jebediah.getX() + 100 && arrow2.getX() >= Jebediah.getX() &&
                                arrow2.getY() >= Jebediah.getY() && arrow2.getY() <= Jebediah.getY() + 125 &&
                                !indianDead2) {
                            gameOver();
                            timer.cancel();
                            indianDead = true;
                            indianDead2 = true;
                        }
                    }
                });
            }
        }, 1, 50);
    }

    public void gameOver() {
        Intent intent = new Intent(this, GameOver.class);
        startActivity(intent);
    }

    public void indianAttack() {
        arrow.setImageResource(R.drawable.arrow);
        final float IndianX = Indian.getX();
        final float IndianY = Indian.getY();
        arrow.setX(IndianX - 1000);
        arrow.setY(IndianY + 410);

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        arrow.setX(arrow.getX() - values.getArrowSpeed());

                        if ((int) arrow.getX() < 0) {
                            arrow.setX(IndianX + 725);
                            arrow.setY(IndianY + 420);
                        }
                    }
                }, 400);
            }
        }, 1000, 50);
    }

    public void indianAttack2() {
        arrow2.setImageResource(R.drawable.arrow);
        final float IndianX = Indian2.getX();
        final float IndianY = Indian2.getY();
        arrow2.setX(IndianX - 225);
        arrow2.setY(IndianY + 160);

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        arrow2.setX(arrow2.getX() - values.getArrowSpeed());

                        if ((int) arrow2.getX() < 0) {
                            arrow2.setX(IndianX + 1500);
                            arrow2.setY(IndianY + 170);
                        }
                    }
                }, 400);
            }
        }, 1000, 50);
    }

    public boolean gotToGold() {
        if (Jebediah.getX() > gold.getX() && Jebediah.getY() < gold.getY()) {
            return true;
        }

        return false;
    }


    public void winLevel() {
        Intent intent = new Intent(this, WinLevel.class);
        startActivity(intent);
    }

    public void fall() {

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (values.fall(Jebediah.getX())) {
                            currentLevel = values.getCurrentLevel();
                            Jebediah.setY(currentLevel);

                        }
                    }
                });
            }
        }, 1, 50);
    }

    public void setVis(){
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (gotToGold()) {
                            next.setVisibility(View.VISIBLE);
                        }
                    }
                }, 400);
            }
        }, 1000, 50);

    }
}
