package com.example.outlawrampagealternate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;


public class StartScreen extends AppCompatActivity implements View.OnTouchListener {

    private ImageButton startButton;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);


        startButton = findViewById(R.id.StartButton);
        startButton.setOnTouchListener(this);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (v.getId()) {
            case R.id.StartButton:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startGame();
                        finish();
                }
                return true;


            default:
                return false;
        }
    }

    public void startGame() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
