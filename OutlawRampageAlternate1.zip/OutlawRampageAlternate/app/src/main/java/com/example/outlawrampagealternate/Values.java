package com.example.outlawrampagealternate;


class Values {
    private int[][] levels = {{0, 0, 634},
                              {350, 1103, 510},
                              {956, 1870, 400}};//268 where 300
    private int currentLevel = 634;
    private int walkingSpeedRight = 5;
    private int walkingSpeedLeft = -5;
    private int jumpUpSpeed = -3;
    private int jumpDownSpeed = 3;
    private int jumpOverSpeed = 1;
    private int bulletSpeed = 50;
    private int arrowSpeed = 20;

    int getCurrentLevel() {
        return currentLevel;
    }

    int getWalkingSpeedRight() {
        return walkingSpeedRight;
    }

    int getWalkingSpeedLeft() {
        return walkingSpeedLeft;
    }

    int getJumpUpSpeed() {
        return jumpUpSpeed;
    }

    int getJumpDownSpeed() {
        return jumpDownSpeed;
    }

    int getJumpOverSpeed() {
        return jumpOverSpeed;
    }

    int getBulletSpeed() {
        return bulletSpeed;
    }

    int getArrowSpeed() {
        return arrowSpeed;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public boolean checkPlatformLevel(float JebX, float JebYPlusHeight) {
        if (JebX > levels[2][0] && JebX < levels[2][1] &&
                JebYPlusHeight < levels[2][2]) {
            currentLevel = levels[2][2] - 270;
            return true;
        }

        if (JebX > levels[1][0] && JebX < levels[1][1] &&
                JebYPlusHeight < levels[1][2]) {
            currentLevel = levels[1][2] - 114;
            return true;
        }

        return false;
    }

    public boolean fall(float JebX) {
        if (currentLevel == levels[0][2]) {
            return false;
        }

        if ((JebX < levels[1][0] || JebX > levels[1][1]) && currentLevel == levels[1][2] - 114) {
            currentLevel = levels[0][2];
            return true;
        }

        if (JebX < levels[2][0] && currentLevel == levels[2][2] - 270) {
            currentLevel = levels[1][2] - 114;
            return true;
        }

        return false;
    }
}
