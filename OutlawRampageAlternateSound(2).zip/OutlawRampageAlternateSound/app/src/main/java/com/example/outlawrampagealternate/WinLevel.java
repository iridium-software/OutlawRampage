package com.example.outlawrampagealternate;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class WinLevel extends AppCompatActivity implements View.OnTouchListener {

    private ImageView background3;
    private ImageButton returnButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win_level);

        background3 = findViewById(R.id.background3);
        background3.setImageResource(R.drawable.victory_scene);

        returnButton = findViewById(R.id.Return);
        returnButton.setOnTouchListener(this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (v.getId()) {
            case R.id.Return:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        goBack();
                        finish();
                }
                return true;


            default:
                return false;
        }
    }

    public void goBack () {
        Intent intent = new Intent(this, StartScreen.class);
        startActivity(intent);
    }
}
