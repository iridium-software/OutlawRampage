package com.example.outlawrampagealternate;


class Values {
    private int[][] levels = {{0, 0, 634},
                              {350, 1103, 510},
                              {956, 1870, 400}};
    private int currentLevel = 634;
    private int walkingSpeedRight = 5;
    private int walkingSpeedLeft = -5;
    private int jumpUpSpeed = -3;
    private int jumpDownSpeed = 3;
    private int jumpOverSpeed = 1;
    private int bulletSpeed = 50;
    private int arrowSpeed = 20;

    int getCurrentLevel() {
        return currentLevel;
    }

    int getWalkingSpeedRight() {
        return walkingSpeedRight;
    }

    int getWalkingSpeedLeft() {
        return walkingSpeedLeft;
    }

    int getJumpUpSpeed() {
        return jumpUpSpeed;
    }

    int getJumpDownSpeed() {
        return jumpDownSpeed;
    }

    int getJumpOverSpeed() {
        return jumpOverSpeed;
    }

    int getBulletSpeed() {
        return bulletSpeed;
    }

    int getArrowSpeed() {
        return arrowSpeed;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public boolean checkPlatformLevel(float JebX, float JebYPlusHeight) {
        if (JebX > levels[2][0] && JebX < levels[2][1] &&
                JebYPlusHeight < levels[2][2]) {
            currentLevel = levels[2][2] - 270;
            return true;
        }

        if (JebX > levels[1][0] && JebX < levels[1][1] &&
                JebYPlusHeight < levels[1][2]) {
            currentLevel = levels[1][2] - 114;
            return true;
        }

        return false;
    }

    public boolean fall (float JebX) {
        if (currentLevel == levels[0][2]) {
            return false;
        }

        if ((JebX < levels[1][0] || JebX > levels[1][1]) && currentLevel == levels[1][2] - 114) {
            currentLevel = levels[0][2];
            return true;
        }

        if (JebX < levels[2][0] && currentLevel == levels[2][2] - 270) {
            currentLevel = levels[1][2] - 114;
            return true;
        }

        return false;
    }

    public boolean gotToGold(float JebX, float JebY) {
        if (JebX > 1704 && JebY < 197) {
            return true;
        }

        return false;
    }

    public boolean killIndian(float bulletX, float bulletY) {
        if (bulletX >= 783 && bulletX <= 783 + 118 &&
                bulletY >= 390 && bulletY <= 390 + 155) {
            return true;
        }

        return false;
    }

    public boolean killIndian2(float bulletX, float bulletY) {
        if (bulletX >= 1529 && bulletX <= 1529 + 118 &&
                bulletY >= 125 && bulletY <= 125 + 155) {
            return true;
        }

        return false;
    }

    public boolean killIndian3(float bulletX, float bulletY) {
        if (bulletX >= 1508 && bulletX <= 1508 + 118 &&
                bulletY >= 623 && bulletY <= 623 + 155) {
            return true;
        }

        return false;
    }

    public boolean killJeb (float JebX, float JebY, float arrowX, float arrowY, boolean indianDead) {
        if (arrowX <= JebX + 100 && arrowX >= JebX &&
                arrowY >= JebY && arrowY <= JebY + 125 &&
                !indianDead) {
            return true;
        }
        return false;
    }

    public float [] indianAttack (float arrowX, int ambushPosition) { // ambushPosition takes values 1, 2, and 3
        float [] ambushXAndY = new float[2];

        if (arrowX < 0 && ambushPosition == 1) {
            ambushXAndY[0] = 750;
            ambushXAndY[1] = 430;
            return ambushXAndY;
        }

        if (arrowX < 0 && ambushPosition == 2) {
            ambushXAndY[0] = 1500;
            ambushXAndY[1] = 170;
            return ambushXAndY;
        }

        if (arrowX < 0 && ambushPosition == 3) {
            ambushXAndY[0] = 1500;
            ambushXAndY[1] = 675;
            return ambushXAndY;
        }

        return new float [] {};
    }
}
