package com.example.outlawrampagealternate;

import org.junit.Test;

import static org.junit.Assert.*;

public class ValuesTest {
    @Test
    public void testCurrentLevel () {
        Values values = new Values();
        float actual = values.getCurrentLevel();

        assertEquals(634, actual, 0.1);
    }

    @Test
    public void testWalkingSpeedRight () {
        Values values = new Values();
        int actual = values.getWalkingSpeedRight();

        assertEquals(5, actual);
    }

    @Test
    public void testWalkingSpeedLeft () {
        Values values = new Values();
        int actual = values.getWalkingSpeedLeft();

        assertEquals(-5, actual);
    }

    @Test
    public void testJumpUpSpeed () {
        Values values = new Values();
        int actual = values.getJumpUpSpeed();

        assertEquals(-3, actual);
    }

    @Test
    public void testJumpDownSpeed () {
        Values values = new Values();
        int actual = values.getJumpDownSpeed();

        assertEquals(3, actual);
    }

    @Test
    public void testJumpOverSpeed () {
        Values values = new Values();
        int actual = values.getJumpOverSpeed();

        assertEquals(1, actual);
    }

    @Test
    public void testBulletSpeed () {
        Values values = new Values();
        int actual = values.getBulletSpeed();

        assertEquals(50, actual);
    }

    @Test
    public void testArrowSpeed () {
        Values values = new Values();
        int actual = values.getArrowSpeed();

        assertEquals(20, actual);
    }

    @Test
    public void testCheckPlatformLevel () {
        Values values = new Values();

        assertTrue(values.checkPlatformLevel(1200, 399));
    }

    @Test
    public void testCheckPlatformLevel2 () {
        Values values = new Values();

        assertTrue(values.checkPlatformLevel(800, 509));
    }

    @Test
    public void testCheckPlatformLevel3 () {
        Values values = new Values();

        assertFalse(values.checkPlatformLevel(5, 300));
    }

    @Test
    public void testCheckPlatformLevel4 () {
        Values values = new Values();

        assertFalse(values.checkPlatformLevel(5, 600));
    }

    @Test
    public void testFall () {
        Values values = new Values();

        assertFalse(values.fall(5));
    }

    @Test
    public void testFall2 () {
        Values values = new Values();

        assertFalse(values.fall(5));
    }

    @Test
    public void testFall3 () {
        Values values = new Values();

        assertFalse(values.fall(1200));
    }

    @Test
    public void testFall4 () {
        Values values = new Values();
        values.setCurrentLevel(396);

        assertTrue(values.fall(5));
    }

    @Test
    public void testFall5 () {
        Values values = new Values();
        values.setCurrentLevel(396);

        assertTrue(values.fall(1200));
    }

    @Test
    public void testFall6 () {
        Values values = new Values();

        assertFalse(values.fall(800));
    }

    @Test
    public void testFall7 () {
        Values values = new Values();
        values.setCurrentLevel(130);

        assertTrue(values.fall(800));
    }

    @Test
    public void testFall8 () {
        Values values = new Values();
        values.setCurrentLevel(130);

        assertFalse(values.fall(1000));
    }

    @Test
    public void testGotToGold () {
        Values values = new Values();

        assertFalse(values.gotToGold(1704, 197));
    }

    @Test
    public void testGotToGold2 () {
        Values values = new Values();

        assertTrue(values.gotToGold(1705, 196));
    }

    @Test
    public void testGotToGold3 () {
        Values values = new Values();

        assertFalse(values.gotToGold(1704, 196));
    }

    @Test
    public void testGotToGold4 () {
        Values values = new Values();

        assertFalse(values.gotToGold(1705, 197));
    }

    @Test
    public void testKillIndian () {
        Values values = new Values();

        assertTrue(values.killIndian(783, 390));
    }

    @Test
    public void testKillIndian2 () {
        Values values = new Values();

        assertFalse(values.killIndian(902, 546));
    }

    @Test
    public void testKillIndian3 () {
        Values values = new Values();

        assertFalse(values.killIndian(902, 390));
    }

    @Test
    public void testKillIndian4 () {
        Values values = new Values();

        assertFalse(values.killIndian(783, 546));
    }

    @Test
    public void testKillIndian21 () {
        Values values = new Values();

        assertTrue(values.killIndian2(1529, 125));
    }

    @Test
    public void testKillIndian22 () {
        Values values = new Values();

        assertFalse(values.killIndian2(1648, 281));
    }

    @Test
    public void testKillIndian23 () {
        Values values = new Values();

        assertFalse(values.killIndian2(1648, 125));
    }

    @Test
    public void testKillIndian24 () {
        Values values = new Values();

        assertFalse(values.killIndian2(1529, 281));
    }

    @Test
    public void testKillIndian31 () {
        Values values = new Values();

        assertTrue(values.killIndian3(1508, 623));
    }

    @Test
    public void testKillIndian32 () {
        Values values = new Values();

        assertFalse(values.killIndian3(1627, 779));
    }

    @Test
    public void testKillIndian33 () {
        Values values = new Values();

        assertFalse(values.killIndian3(1627, 623));
    }

    @Test
    public void testKillIndian34 () {
        Values values = new Values();

        assertFalse(values.killIndian3(1508, 779));
    }

    @Test
    public void testKillJeb () {
        Values values = new Values();

        assertTrue(values.killJeb(5, 5, 5, 5, false));
    }

    @Test
    public void testKillJeb2 () {
        Values values = new Values();

        assertFalse(values.killJeb(5, 5, 5, 5, true));
    }

    @Test
    public void testKillJeb3 () {
        Values values = new Values();

        assertFalse(values.killJeb(4, 4, 5, 5, true));
    }

    @Test
    public  void testIndianAttack () {
        Values values = new Values();

        assertEquals(0, values.indianAttack(0, 4).length);
    }

    @Test
    public  void testIndianAttack2 () {
        Values values = new Values();

        assertEquals(0, values.indianAttack(-1, 0).length);
    }

    @Test
    public  void testIndianAttack3 () {
        Values values = new Values();

        assertEquals(0, values.indianAttack(1, 1).length);
    }

    @Test
    public  void testIndianAttack4 () {
        Values values = new Values();
        float [] answer = values.indianAttack(-1, 1);

        if (answer[0] != 750) {
            fail();
        } else if (answer[1] != 430) {
            fail();
        }
    }

    @Test
    public  void testIndianAttack5 () {
        Values values = new Values();
        float [] answer = values.indianAttack(-1, 2);

        if (answer[0] != 1500) {
            fail();
        } else if (answer[1] != 170) {
            fail();
        }
    }

    @Test
    public  void testIndianAttack6 () {
        Values values = new Values();
        float [] answer = values.indianAttack(-1, 3);

        if (answer[0] != 1500) {
            fail();
        } else if (answer[1] != 675) {
            fail();
        }
    }
}