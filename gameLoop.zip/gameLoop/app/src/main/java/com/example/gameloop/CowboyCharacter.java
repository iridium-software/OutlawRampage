package com.example.gameloop;

import android.graphics.Canvas;
import android.graphics.Point;


public class CowboyCharacter extends GameObject {

    @Override
    public void draw (Canvas canvas) {

    }

    @Override
    public void update() {

    }

    public void update(Point point) {

    }

}
