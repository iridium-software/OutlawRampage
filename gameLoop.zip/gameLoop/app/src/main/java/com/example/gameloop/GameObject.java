package com.example.gameloop;

import android.graphics.Canvas;

public class GameObject {

    public void draw(Canvas canvas) {

    }

    public void update() {

    }

}